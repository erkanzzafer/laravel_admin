<?php $__env->startSection('content'); ?>
<main class="container">
    <section>
        <div class="titlebar">
            <h1>Category</h1>
           <a href="<?php echo e(route('category.create')); ?>"> <button>Add Category</button></a>
        </div>
         <?php if($message=Session::get('success')): ?>
          <script type="text/javascript">
            const Toast = Swal.mixin({
                toast: true,
                position: 'top-end',
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                  toast.addEventListener('mouseenter', Swal.stopTimer)
                  toast.addEventListener('mouseleave', Swal.resumeTimer)
                }
              })

              Toast.fire({
                icon: 'success',
                title: '<?php echo e($message); ?>'
              })

         </script>
         <?php endif; ?>

        <div class="table">
            <div class="table-filter">
                <div>
                    <ul class="table-filter-list">
                        <li>
                            <p class="table-filter-link link-active">All</p>
                        </li>
                    </ul>
                </div>
            </div>
        <form action="<?php echo e(route('category.index')); ?>" method="GET" accept-charset="UTF-8" role="search">
            <div class="table-search">
                <div>
                    <button class="search-select">
                       Search Category
                    </button>
                    <span class="search-select-arrow">
                        <i class="fas fa-caret-down"></i>
                    </span>
                </div>
                <div class="relative">
                    <input class="search-input" type="text" placeholder="Search category..." name="search" value="<?php echo e(request('search')); ?>">
                </div>
            </div>
        </form>
            <div class="table-product-head">

                <p>Name</p>

                <p>Actions</p>
            </div>
            <div class="table-product-body" >
                <?php if(count($categories)>0): ?>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <p> <?php echo e($category->name); ?></p>


                    <div style="display: flex">
                        <a href="<?php echo e(route('category.edit',$category->id)); ?>">
                        <button class="btn btn-success" style="padding-top: 4px;paddin-bottom:4px">
                            <i class="fas fa-pencil-alt" ></i>
                        </button>
                        </a>
                        <form action="<?php echo e(route('category.destroy',$category->id)); ?>" method="POST">
                          <?php echo method_field('delete'); ?>
                          <?php echo csrf_field(); ?>
                             <button class="btn btn-danger" onclick="deleteConfirm(event)">
                              <i class="far fa-trash-alt"></i>
                            </button>
                        </form>


                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <p>Kategori Bulunamadı
                    </p>
                <?php endif; ?>


            </div>
            <div class="table-paginate">
            <?php echo e($categories->links('layouts.pagination')); ?>


            </div>
        </div>
    </section>
</main>
<script>
window.deleteConfirm=function(e){
    e.preventDefault();
    var form=e.target.form;
    Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
            if (result.isConfirmed) {
                form.submit();
            }
            })



}

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\crud\resources\views/category/index.blade.php ENDPATH**/ ?>