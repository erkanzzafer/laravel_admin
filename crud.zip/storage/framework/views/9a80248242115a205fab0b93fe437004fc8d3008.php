<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.bunny.net/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">



        <style>
            body {
                font-family: 'Nunito', sans-serif;
                background-color: white;
                color: white;
            }
        </style>
        <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>
    </head>
    <body>
<div class="contaioner"><a href="/"><h3>Anasayfa</h3></a></div>

            <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
<?php /**PATH C:\Users\HP\Desktop\crud\resources\views/layouts/app.blade.php ENDPATH**/ ?>