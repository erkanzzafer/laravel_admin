<?php $__env->startSection('content'); ?>
    <main class="container">
        <section>
            <form method="post" action="<?php echo e(route('category.update',$category->id)); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="titlebar">
                    <h1>Edit Category</h1>
                    <button>Save</button>
                </div>
                <?php if($errors->any()): ?>
                    <div>
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?> </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <div class="card">
                <div>
                        <label>Name</label>
                        <input type="text" name="name" value="<?php echo e($category->name); ?>">
                    </div>
                <div>
                </div>
                </div>
                <div class="titlebar">
                    <h1></h1>
                    <input type="hidden" name="hidden_id" value="<?php echo e($category->id); ?>">
                    <button>Save</button>
                </div>
         </form>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Desktop\crud\resources\views/category/edit.blade.php ENDPATH**/ ?>